import { createContext, useContext, useState, useCallback, useEffect } from 'react'
import { supabase } from './supabase'
import { UNIT_IDS, defaultUnitConfig, buildZones } from '../data/units'

const AppContext = createContext(null)

function emptyState() {
  const configs = {}
  const items = {}
  UNIT_IDS.forEach(id => {
    configs[id] = defaultUnitConfig(id)
    items[id] = {}
    buildZones(configs[id].numCofres, configs[id].hasTecho, configs[id].hasTrasera)
      .forEach(z => { items[id][z.id] = [] })
  })
  return { configs, items }
}

export function AppProvider({ children }) {
  const [state, setState]         = useState(emptyState)
  const [loading, setLoading]     = useState(true)
  const [toast, setToast]         = useState(null)
  const [session, setSession]     = useState(null)
  const [authReady, setAuthReady] = useState(false)
  const [reviews, setReviews]     = useState({})
  const [itemStates, setItemStates] = useState({})
  const [revisionIncidents, setRevisionIncidents] = useState([])  // incidencias de informes BV de hoy

  // ── Auth ──────────────────────────────────────────────
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setAuthReady(true)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
    })
    return () => subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (!authReady) return
    if (!session) { setLoading(false); return }
    loadAll()
  }, [authReady, session?.user?.id])

  // ── Carga de datos ────────────────────────────────────
  async function loadAll() {
    setLoading(true)
    try {
      const { data: cfgData, error: cfgErr } = await supabase.from('unit_configs').select('*')
      if (cfgErr) throw cfgErr

      const configs = {}
      UNIT_IDS.forEach(id => { configs[id] = defaultUnitConfig(id) })
      cfgData.forEach(row => {
        configs[row.unit_id] = { numCofres: row.num_cofres, hasTecho: row.has_techo, hasTrasera: row.has_trasera }
      })

      const { data: itemData, error: itemErr } = await supabase
        .from('unit_items').select('*').order('created_at', { ascending: true })
      if (itemErr) throw itemErr

      const items = {}
      UNIT_IDS.forEach(id => {
        items[id] = {}
        buildZones(configs[id].numCofres, configs[id].hasTecho, configs[id].hasTrasera)
          .forEach(z => { items[id][z.id] = [] })
      })
      itemData.forEach(row => {
        if (!items[row.unit_id]) return
        if (!items[row.unit_id][row.zone_id]) items[row.unit_id][row.zone_id] = []
        items[row.unit_id][row.zone_id].push({
          id: row.id, name: row.name, desc: row.description, qty: row.qty, min: row.min_qty
        })
      })
      setState({ configs, items })

      const { data: revData } = await supabase
        .from('unit_reviews').select('*').order('reviewed_at', { ascending: false })
      const latestReviews = {}
      if (revData) revData.forEach(r => { if (!latestReviews[r.unit_id]) latestReviews[r.unit_id] = r })
      setReviews(latestReviews)

      // Incidencias de revisión diaria de hoy
      const todayDate = new Date().toISOString().slice(0, 10)
      const { data: todayReports } = await supabase
        .from('revision_reports')
        .select('*')
        .eq('report_date', todayDate)
        .eq('is_ok', false)
      const revInc = []
      if (todayReports) {
        todayReports.forEach(r => {
          (r.incidents || []).forEach(inc => {
            revInc.push({ source: 'revision', unitId: r.unit_id, zone: inc.zone, item: inc.item, note: inc.note || '', bomberoId: r.bombero_id })
          })
        })
      }
      setRevisionIncidents(revInc)

    } catch (err) {
      console.error('Error cargando datos:', err)
      showToast('Error de conexión', 'error')
    } finally {
      setLoading(false)
    }
  }

  // ── Toast ─────────────────────────────────────────────
  const showToast = useCallback((msg, type = 'ok') => {
    setToast({ msg, type, id: Date.now() })
    setTimeout(() => setToast(null), 2500)
  }, [])

  // ── Logout ────────────────────────────────────────────
  const logout = useCallback(async () => {
    await supabase.auth.signOut()
    setState(emptyState())
    setReviews({})
    setItemStates({})
  }, [])

  // ── Item states (revisión por artículo) ───────────────
  const setUnitItemState = useCallback((unitId, itemId, state) => {
    setItemStates(prev => ({
      ...prev,
      [unitId]: { ...(prev[unitId] || {}), [itemId]: state }
    }))
  }, [])

  const setUnitAllItemStates = useCallback((unitId, states) => {
    setItemStates(prev => ({
      ...prev,
      [unitId]: { ...(prev[unitId] || {}), ...states }
    }))
  }, [])

  // ── Revisión de unidad ────────────────────────────────
  const refreshRevisionIncidents = useCallback(async () => {
    const todayDate = new Date().toISOString().slice(0, 10)
    const { data } = await supabase
      .from('revision_reports')
      .select('*')
      .eq('report_date', todayDate)
      .eq('is_ok', false)
    const revInc = []
    if (data) {
      data.forEach(r => {
        (r.incidents || []).forEach(inc => {
          revInc.push({ source: 'revision', unitId: r.unit_id, zone: inc.zone, item: inc.item, note: inc.note || '', bomberoId: r.bombero_id })
        })
      })
    }
    setRevisionIncidents(revInc)
  }, [])

  const reviewUnit = useCallback(async (unitId, notes = '', isOk = true) => {
    const userEmail = session?.user?.email || 'desconocido'
    const { data, error } = await supabase
      .from('unit_reviews')
      .insert({ unit_id: unitId, reviewed_by: userEmail, notes, is_ok: isOk })
      .select().single()
    if (error) { showToast('Error al guardar revisión', 'error'); return null }
    setReviews(prev => ({ ...prev, [unitId]: data }))
    showToast('✔ Revisión registrada', 'ok')
    return data
  }, [session, showToast])

  // ── CRUD artículos ────────────────────────────────────
  const updateQty = useCallback(async (unitId, zoneId, itemId, delta) => {
    let newQty
    setState(prev => {
      const zoneItems = (prev.items[unitId][zoneId] || []).map(it => {
        if (it.id === itemId) { newQty = Math.max(0, it.qty + delta); return { ...it, qty: newQty } }
        return it
      })
      return { ...prev, items: { ...prev.items, [unitId]: { ...prev.items[unitId], [zoneId]: zoneItems } } }
    })
    const { error } = await supabase.from('unit_items').update({ qty: newQty }).eq('id', itemId)
    if (error) showToast('Error al guardar', 'error')
  }, [showToast])

  const addItem = useCallback(async (unitId, zoneId, item) => {
    const { data, error } = await supabase
      .from('unit_items')
      .insert({ unit_id: unitId, zone_id: zoneId, name: item.name, description: item.desc || '', qty: item.qty, min_qty: item.min })
      .select().single()
    if (error) { showToast('Error al guardar', 'error'); return null }
    const newItem = { id: data.id, name: data.name, desc: data.description, qty: data.qty, min: data.min_qty }
    setState(prev => ({
      ...prev,
      items: { ...prev.items, [unitId]: { ...prev.items[unitId], [zoneId]: [...(prev.items[unitId][zoneId] || []), newItem] } }
    }))
    return newItem
  }, [showToast])

  const deleteItem = useCallback(async (unitId, zoneId, itemId) => {
    const { error } = await supabase.from('unit_items').delete().eq('id', itemId)
    if (error) { showToast('Error al eliminar', 'error'); return }
    setState(prev => ({
      ...prev,
      items: { ...prev.items, [unitId]: { ...prev.items[unitId], [zoneId]: prev.items[unitId][zoneId].filter(it => it.id !== itemId) } }
    }))
  }, [showToast])

  const editItem = useCallback(async (unitId, zoneId, itemId, changes) => {
    const { error } = await supabase
      .from('unit_items')
      .update({ name: changes.name, description: changes.desc, qty: changes.qty, min_qty: changes.min })
      .eq('id', itemId)
    if (error) { showToast('Error al guardar', 'error'); return }
    setState(prev => ({
      ...prev,
      items: { ...prev.items, [unitId]: { ...prev.items[unitId], [zoneId]: prev.items[unitId][zoneId].map(it => it.id === itemId ? { ...it, ...changes } : it) } }
    }))
  }, [showToast])

  const updateUnitConfig = useCallback(async (unitId, newConfig) => {
    const { error } = await supabase.from('unit_configs').upsert({
      unit_id: unitId, num_cofres: newConfig.numCofres, has_techo: newConfig.hasTecho, has_trasera: newConfig.hasTrasera,
    })
    if (error) { showToast('Error al guardar configuración', 'error'); return }
    setState(prev => {
      const zones = buildZones(newConfig.numCofres, newConfig.hasTecho, newConfig.hasTrasera)
      const updatedItems = { ...prev.items[unitId] }
      zones.forEach(z => { if (!updatedItems[z.id]) updatedItems[z.id] = [] })
      return { ...prev, configs: { ...prev.configs, [unitId]: newConfig }, items: { ...prev.items, [unitId]: updatedItems } }
    })
  }, [showToast])

  return (
    <AppContext.Provider value={{
      session, authReady, logout,
      configs: state.configs, items: state.items, reviews,
      loading, toast, showToast,
      itemStates, setUnitItemState, setUnitAllItemStates,
      revisionIncidents, refreshRevisionIncidents,
      reviewUnit, updateQty, addItem, deleteItem, editItem, updateUnitConfig,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() { return useContext(AppContext) }
